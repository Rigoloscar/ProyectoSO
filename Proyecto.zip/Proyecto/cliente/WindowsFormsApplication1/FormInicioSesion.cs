﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace WindowsFormsApplication1
{
    public partial class FormInicioSesion : Form
    {
        Socket server;
        public FormInicioSesion()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 50000);

            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        private void entrarButton_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(usuarioTextBox.Text) && !string.IsNullOrEmpty(contraseñaTextBox.Text))
            {
                // Preparamos el mensaje concatenando el usuario y la contraseña con un delimitador
                string msgUsuario = usuarioTextBox.Text;
                string msgContraseña = contraseñaTextBox.Text;
                string mensaje = msgUsuario + "/" + msgContraseña; // Usamos "/" como delimitador

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);        // Enviamos al servidor el usuario
                server.Send(msg);
                this.BackColor = Color.Gray;
            }
            else
            {
                MessageBox.Show("Introduce usuario y contraseña");
            }

            if (server != null)
            {
                server.Shutdown(SocketShutdown.Both); // Finalizamos la conexión correctamente
                server.Close();                       // Cerramos el socket

                FormInterfaz formInterfaz = new FormInterfaz();
                formInterfaz.ShowDialog();
                this.Close();
            }
        }
        private void crearusuarioButton_Click(object sender, EventArgs e)
        {
            FormCrearUsuario formCrearUsuario = new FormCrearUsuario();
            formCrearUsuario.ShowDialog();
            this.Close();
        }
    }
}
