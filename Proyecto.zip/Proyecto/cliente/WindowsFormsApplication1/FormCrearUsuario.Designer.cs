﻿namespace WindowsFormsApplication1
{
    partial class FormCrearUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guardarButton = new System.Windows.Forms.Button();
            this.creaUsuarioText = new System.Windows.Forms.Label();
            this.insertausuarioTextBox = new System.Windows.Forms.TextBox();
            this.creaContraseñaText = new System.Windows.Forms.Label();
            this.creaContraseñaTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // guardarButton
            // 
            this.guardarButton.Location = new System.Drawing.Point(672, 823);
            this.guardarButton.Name = "guardarButton";
            this.guardarButton.Size = new System.Drawing.Size(235, 83);
            this.guardarButton.TabIndex = 0;
            this.guardarButton.Text = "Guardar";
            this.guardarButton.UseVisualStyleBackColor = true;
            // 
            // creaUsuarioText
            // 
            this.creaUsuarioText.AutoSize = true;
            this.creaUsuarioText.Location = new System.Drawing.Point(387, 225);
            this.creaUsuarioText.Name = "creaUsuarioText";
            this.creaUsuarioText.Size = new System.Drawing.Size(180, 32);
            this.creaUsuarioText.TabIndex = 1;
            this.creaUsuarioText.Text = "Crea Usuario";
            // 
            // insertausuarioTextBox
            // 
            this.insertausuarioTextBox.Location = new System.Drawing.Point(720, 225);
            this.insertausuarioTextBox.Name = "insertausuarioTextBox";
            this.insertausuarioTextBox.Size = new System.Drawing.Size(323, 38);
            this.insertausuarioTextBox.TabIndex = 2;
            this.insertausuarioTextBox.Text = "Ex: Jugador1234";
            // 
            // creaContraseñaText
            // 
            this.creaContraseñaText.AutoSize = true;
            this.creaContraseñaText.Location = new System.Drawing.Point(387, 330);
            this.creaContraseñaText.Name = "creaContraseñaText";
            this.creaContraseñaText.Size = new System.Drawing.Size(229, 32);
            this.creaContraseñaText.TabIndex = 3;
            this.creaContraseñaText.Text = "Crea Contraseña";
            // 
            // creaContraseñaTextBox
            // 
            this.creaContraseñaTextBox.Location = new System.Drawing.Point(730, 345);
            this.creaContraseñaTextBox.Name = "creaContraseñaTextBox";
            this.creaContraseñaTextBox.Size = new System.Drawing.Size(323, 38);
            this.creaContraseñaTextBox.TabIndex = 4;
            // 
            // FormCrearUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1622, 1183);
            this.Controls.Add(this.creaContraseñaTextBox);
            this.Controls.Add(this.creaContraseñaText);
            this.Controls.Add(this.insertausuarioTextBox);
            this.Controls.Add(this.creaUsuarioText);
            this.Controls.Add(this.guardarButton);
            this.Name = "FormCrearUsuario";
            this.Text = "FormCrearUsuario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button guardarButton;
        private System.Windows.Forms.Label creaUsuarioText;
        private System.Windows.Forms.TextBox insertausuarioTextBox;
        private System.Windows.Forms.Label creaContraseñaText;
        private System.Windows.Forms.TextBox creaContraseñaTextBox;
    }
}