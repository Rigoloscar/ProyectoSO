#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql.h>
#include "cabecera.h"

int sock_conn, sock_listen, ret;
struct sockaddr_in serv_adr;
char buff[512];
char *usuario = NULL;
char *contrasena = NULL;				//Declaramos variables

// Función para inicializar el socket
void inicializar_socket()
{
	// Abrimos el socket
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creando socket");
	
	// Hacemos el bind al puerto
	memset(&serv_adr, 0, sizeof(serv_adr)); // inicializa a cero serv_addr
	serv_adr.sin_family = AF_INET;
	
	// Asignamos la IP de la máquina virtual
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	// Escucharemos en el puerto 50000
	serv_adr.sin_port = htons(50000);
	
	if (bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr)) < 0)
		printf("Error en el bind");
	
	// La cola de peticiones pendientes no podrá ser superior a 2
	if (listen(sock_listen, 2) < 0)
		printf("Error en el listen");
}

void obtener_usuario_contrasena()
{
	// Ahora recibimos los datos del cliente, que dejamos en buff
	ret = read(sock_conn, buff, sizeof(buff));
	if (ret > 0)
	{
		// Añadimos la marca de fin de cadena
		buff[ret] = '\0';
		printf("Recibido: %s\n", buff);
		
		// Separar el usuario y la contraseña usando un delimitador (por ejemplo, "/")
		usuario = strtok(buff, "/");
		contrasena = strtok(NULL, "/");
		
	}
	if (usuario && contrasena)
	{
		// Mostramos el usuario y la contraseña recibidos
		printf("Usuario: %s, Contrase�a: %s\n", usuario, contrasena);
	}
	else
	{
		printf("Error al procesar los datos recibidos.\n");
	}
}
void socketGlobal(){
	// Llamamos a la función para inicializar el socket
	inicializar_socket();
	
	int i;
	// Atenderemos solo 10 peticiones. Cada variable es una peticion, por tanto para mas eficiencia enviamos usuario y contrase￱a juntos en una variable y luego los separamos.
	for (i = 0; i < 10; i++)
	{
		printf("Escuchando\n");
		sock_conn = accept(sock_listen, NULL, NULL);
		printf("He recibido conexión\n");
		// sock_conn es el socket que usaremos para este cliente
		
		// Llamamos a la función para obtener el usuario y contraseña
		obtener_usuario_contrasena();
		buscarUserBBDD();
		
		
		// Se acabo el servicio para este cliente
		close(sock_conn); 
	}
	
	// Cerramos el socket principal
	close(sock_listen);
}

int main(int argc, char *argv[])
{
	socketGlobal();
	buscarUserBBDD();
	return 0;
}
