#include "cabecera.h"															//Abrimos el archivo de cabecera que contiene todas las librerias y funciones.

int sock_conn, sock_listen, ret;												//Declaramos variables
struct sockaddr_in serv_adr;
char buff[512];
char *usuario = NULL;
char *contrasena = NULL;

void inicializarSocket()														
{
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0){					// Abrimos el socket
		printf("Error creando socket");											//Check point
		exit(1);																	//Salimos si no se puede crear el socket
	}
	memset(&serv_adr, 0, sizeof(serv_adr)); 									// Hacemos bind al puerto, inicializazando a zero serv_addr
	serv_adr.sin_family = AF_INET;
	
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);								//Asignamos IP de la maquina virtual donde se ejecuta el codigo
	
	serv_adr.sin_port = htons(50000);											// Escucharemos en el puerto 50000
	
	if (bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr)) < 0){
		printf("Error en el bind");
		exit(1);
	}
	if (listen(sock_listen, 2) < 0){											// La cola de peticiones pendientes no podra ser superior a 2
		printf("Error en el listen");
	}
	printf("Servidor iniciado correctamente. Escuchando en puerto 50000\n");
}

void establecerConexion()														
{
	printf("Esperando conexion...\n");
	while (1)																	//Bucle infinito para escuchar conexiones
	{
		sock_conn = accept(sock_listen, NULL, NULL);							//Aceptamos la conexion
		if (sock_conn < 0) {
			printf("Error aceptando conexión.\n");
			continue;  															// Si falla, seguimos escuchando
		}
		printf("Conexion aceptada.\n");

		obtener_mensajeCliente();												//Procesamos el mensaje
		
		//close(sock_conn); 														//Cerrar conexion tras recibir el mesaje, el servidor seguira escuchando
		//printf("Conexion cerrada.\n");
	}
	close(sock_listen);  														//Nunca se alcanzara
}

void obtener_mensajeCliente()													
{
	char buff[512];
	int ret;
	
	while ((ret = read(sock_conn, buff, sizeof(buff))) > 0) {
		buff[ret] = '\0';
		printf("Mensaje recibido: %s\n", buff);
		procesar_mensaje(buff);  // Procesar el mensaje
	}
	if (ret == 0) {
		printf("El cliente ha cerrado la conexión.\n");
	} else {
		printf("Error al leer el mensaje del cliente.\n");
	}
}




void procesar_mensaje(char* mensaje)
{
	if (strcmp(mensaje, "CREAR_BD") == 0){										//Mensaje para crear base de datos
		printf("Recibido mensaje para crear la base de datos\n");
		
		conectarMySQL();
		entrarBD();
		crearAndBorrarBBDD();
		
		char respuesta[] = "OK";												//Enviamos respuesta al cliente
		write(sock_conn, respuesta, strlen(respuesta));
	}
	
	if (strcmp(mensaje, "CONTAR_USERS") == 0){									//Mensaje para contar usuarios
		printf("Recibido mensaje para contar usuarios\n");
		
		conectarMySQL();
		entrarBD();
		int totalUsuarios = contarUsuariosBBDD();
		
		// Preparar respuesta con el número de usuarios
		char respuesta[512];
		snprintf(respuesta, sizeof(respuesta), "TOTAL_USERS:%d", totalUsuarios);												//Enviamos respuesta al cliente
		write(sock_conn, respuesta, strlen(respuesta));
	}
	
	if (strncmp(mensaje, "AUTENTICAR/", 11) == 0) {
		
		usuario = strtok(mensaje + 11, "/");									// Extraer usuario y contrasena del mensaje para autenticar
		contrasena = strtok(NULL, "/");
		if (usuario && contrasena) {
			printf("Usuario: %s, Contrase�a: %s\n", usuario, contrasena);
			printf("Autenticando usuario: %s\n", usuario);
			
			buscarUserAndPassBBDD();
		}
	}
	
	if (strncmp(mensaje, "CAMBIAR_PASS/", 13) == 0) {
			
		usuario = strtok(mensaje + 13, "/");									// Extraer usuario y contrasena del mensaje para autenticar
		contrasena = strtok(NULL, "/");
		if (usuario && contrasena) {
			printf("Usuario: %s, Contrase�a: %s\n", usuario, contrasena);
			printf("Autenticando usuario: %s\n", usuario);
			buscarUserAndChangePassBBDD();
		}
		else{
			printf("No se puede extraer usuario y contrasena.\n");
			char respuesta[] = "ERROR";												//Enviamos respuesta negativa
			write(sock_conn, respuesta, strlen(respuesta));						
		}
	}
	
	if (strncmp(mensaje, "ADD_USER/", 9) == 0) {
	
		usuario = strtok(mensaje + 9, "/");									// Extraer usuario y contrasena del mensaje para autenticar
		contrasena = strtok(NULL, "/");
		if (usuario && contrasena) {
			printf("Usuario: %s, Contrase�a: %s\n", usuario, contrasena);
			printf("Creando usuario: %s\n", usuario);
			
			conectarMySQL();
			entrarBD();
			insertarUsuario();
		}
		else{
			printf("No se puede crear el usuario.\n");
			char respuesta[] = "ERROR";												//Enviamos respuesta negativa
			write(sock_conn, respuesta, strlen(respuesta));						
		}
	}
	//else {
		//char respuesta[] = "COMANDO_NO_RECONOCIDO";  							// Si el comando no es reconocido
		//write(sock_conn, respuesta, strlen(respuesta));
		//printf("Comando no reconocido: %s\n", mensaje);
	//}
}


int main(int argc, char *argv[])
{
	inicializarSocket();
	establecerConexion();

	return 0;																	//Nunca se alcanzara
}
