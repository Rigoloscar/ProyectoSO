#ifndef CABECERA_H
#define CABECERA_H

#include <mysql.h>

// Declaración de variables globales con `extern`
extern char *usuario;
extern char *contrasena;

// Declaración de las funciones que quieres usar en servidor.c
void conectarMySQL();
void entrarBD();
void buscarUserBBDD();
void crearAndBorrarBBDD();
void usarBBDD();
void crearTablaUsuarios();

#endif

