// programa en C para comparar los datos en la base de datos
//Incluir esta libreria para poder hacer las llamadas en shiva2.upc.es
//#include <my_global.h>
#include <mysql.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "cabecera.h"

MYSQL *conn;
MYSQL_RES *resultado;
MYSQL_ROW row;

char *userDB;
char *passDB;

void conectarMySQL()
{

	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn==NULL) {
		printf ("Error al crear la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}

void entrarBD()
{
	//inicializar la conexiￃﾳn, entrando nuestras claves de acceso y
	//el nombre de la base de datos a la que queremos acceder 
	conn = mysql_real_connect (conn, "localhost","root", "mysql", "Usuarios",0, NULL, 0);
	if (conn==NULL) {
		printf ("Error al inicializar la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}

void buscarUserBBDD()
{
	conectarMySQL();
	entrarBD();
	int encontrado = 0;
	int err;
	err=mysql_query (conn, "SELECT * FROM Usuarios;");
	if (err!=0) {
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	resultado = mysql_store_result (conn);
	row = mysql_fetch_row (resultado);
	if (row == NULL)
		printf ("No se han obtenido datos en la consulta\n");
	else
		while (row !=NULL && encontrado==0) {
			// la columna 2 contiene una palabra que es la edad

			userDB = row[1];
			passDB = row[2];
			// las columnas 0 y 1 contienen DNI y nombre
			if ((strcmp(userDB, usuario) ==0) && (strcmp(passDB,contrasena)==0)){
				encontrado = 1;
				printf("EncontradoooOOOOOO\n");
			}
	
			// obtenemos la siguiente fila
			row = mysql_fetch_row (resultado);
	}		
}

void crearAndBorrarBBDD(){
	int err;
	mysql_query(conn, "drop database if exists personas;"); 
	err=mysql_query(conn, "create database Usuarios;");
	if (err!=0) {
		printf ("Error al crear la base de datos %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}

void usarBBDD(){
	int err;
	//indicamos la base de datos con la que queremos trabajar 
	err=mysql_query(conn, "use Usuarios;");
	if (err!=0)
	{
		printf ("Error al crear la base de datos %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	
}

void crearTablaUsuarios(){
	int err;
	err=mysql_query(conn,"CREATE TABLE personas (DNI VARCHAR(10) not null primary key, nombre VARCHAR(25), edad int)");
	
	if (err!=0){
		printf ("Error al definir la tabla %u %s\n",mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}


