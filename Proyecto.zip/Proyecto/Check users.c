// programa en C para comparar los datos en la base de datos
//Incluir esta libreria para poder hacer las llamadas en shiva2.upc.es
//#include <my_global.h>
#include "cabecera.h"

MYSQL *conn;
MYSQL_RES *resultado;
MYSQL_ROW row;

char *userDB;
char *passDB;

void conectarMySQL()
{

	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn==NULL) {
		printf ("Error al crear la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}

void entrarBD()
{
	//inicializar la conexiￃﾳn, entrando nuestras claves de acceso y
	//el nombre de la base de datos a la que queremos acceder 
	conn = mysql_real_connect (conn, "localhost","root", "mysql", "Usuarios",0, NULL, 0);
	if (conn==NULL) {
		printf ("Error al inicializar la conexion: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
}

void buscarUserAndChangePassBBDD()
{
	conectarMySQL();
	entrarBD();
	int encontrado = 0;
	int err;
	err=mysql_query (conn, "SELECT * FROM Usuarios;");
	if (err!=0) {
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	resultado = mysql_store_result (conn);
	row = mysql_fetch_row (resultado);
	if (row == NULL){
		printf ("No se han obtenido datos en la consulta\n");
		return;
	}
	while (row !=NULL && encontrado==0) {
		
		userDB = row[1];
		printf("Comparando Usuario: %s con %s\n", userDB, usuario);
		if ((strcmp(userDB, usuario) ==0)){
			encontrado = 1;
			printf("Usuario encontrado: %s\n", userDB);
		}
		row = mysql_fetch_row(resultado);
	}
	
	if (encontrado == 1) {
		// Usuario encontrado, procedemos a actualizar la contraseña
		char query[512];
		snprintf(query, sizeof(query), "UPDATE Usuarios SET contrasena='%s' WHERE usuario='%s';", contrasena, usuario);
		
		// Ejecutamos la consulta de actualización
		err = mysql_query(conn, query);
		if (err != 0) {
			printf("Error al actualizar la contraseña: %u %s\n", mysql_errno(conn), mysql_error(conn));
			char respuesta[] = "ERROR_ACTUALIZACION";
			write(sock_conn, respuesta, strlen(respuesta));
		} else {
			printf("Contraseña actualizada para el usuario: %s\n", usuario);
			char respuesta[] = "OK";
			write(sock_conn, respuesta, strlen(respuesta));
		}
	} 
	else {
		// Enviar "ERROR" al cliente si no son válidas
		char respuesta[] = "ERROR";
		printf("Usuario no encontrado, ERROR\n");
		write(sock_conn, respuesta, strlen(respuesta));
	}
	
	// Liberamos el resultado
	mysql_free_result(resultado);	
}



void buscarUserAndPassBBDD()
{
	conectarMySQL();
	entrarBD();
	int encontrado = 0;
	int err;
	err=mysql_query (conn, "SELECT * FROM Usuarios;");
	if (err!=0) {
		printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	resultado = mysql_store_result (conn);
	row = mysql_fetch_row (resultado);
	if (row == NULL){
		printf ("No se han obtenido datos en la consulta\n");
		return;
	}
	while (row !=NULL && encontrado==0) {

		userDB = row[1];
		passDB = row[2];
		printf("Comparando Usuario: %s con %s y Contraseña: %s con %s\n", userDB, usuario, passDB, contrasena);
		if ((strcmp(userDB, usuario) ==0) && (strcmp(passDB,contrasena)==0)){
			encontrado = 1;
			printf("Usuario encontrado: %s\n", userDB);
		}
		row = mysql_fetch_row(resultado);
	}

	if (encontrado == 1) {
		// Enviar "OK" al cliente si las credenciales son válidas
		char respuesta[] = "OK";
		printf("OK\n");
		write(sock_conn, respuesta, strlen(respuesta));
	} 
	else {
		// Enviar "ERROR" al cliente si no son válidas
		char respuesta[] = "ERROR";
		printf("Usuario no encontrado, ERROR\n");
		write(sock_conn, respuesta, strlen(respuesta));
	}
	
	// Liberamos el resultado
	mysql_free_result(resultado);	
}

void crearAndBorrarBBDD(){
	int err;
	
	// Intentamos eliminar la base de datos si existe
	mysql_query(conn, "DROP DATABASE IF EXISTS Usuarios;");
	// Intentamos crear la base de datos
	err = mysql_query(conn, "CREATE DATABASE Usuarios;");
	if (err != 0) {
		printf("Error al crear la base de datos: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	} else {
		printf("Base de datos creada correctamente.\n");
	}
	
	// Seleccionamos la base de datos
	err = mysql_query(conn, "USE Usuarios;");
	if (err != 0) {
		printf("Error al usar la base de datos: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	// Creamos la tabla de usuarios
	err = mysql_query(conn, "CREATE TABLE Usuarios (id int primary key not null auto_increment, usuario TEXT not null, contrasena TEXT not null);");
	if (err != 0) {
		printf("Error al crear la tabla Usuarios: %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	// Insertamos el usuario y la contraseña predeterminados
	char query[512];
	snprintf(query, sizeof(query), "INSERT INTO Usuarios (usuario, contrasena) VALUES ('root', 'root')");
	
	err = mysql_query(conn, query);
	if (err != 0) {
		printf("Error al insertar el usuario predeterminado %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	} else {
		printf("Usuario predeterminado insertado corrctamente: root, root");
	}
}


void insertarUsuario()
{
	int encontrado = 0;
	char query[512];
	int err;
	
	// Preparamos la consulta SQL para insertar el usuario y la contraseña
	snprintf(query, sizeof(query), "INSERT INTO Usuarios (usuario, contrasena) VALUES ('%s', '%s')", usuario, contrasena);
	
	// Ejecutamos la consulta
	err = mysql_query(conn, query);
	
	if (err != 0) {
		// Si ocurre un error, lo mostramos
		printf("Error al insertar el usuario %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	} else {
		// Confirmamos que el usuario fue insertado correctamente
		printf("Usuario '%s' insertado correctamente.\n", usuario);
		encontrado = 1;
	}
	if (encontrado == 1) {
		// Enviar "OK" al cliente si las credenciales son válidas
		char respuesta[] = "OK";
		write(sock_conn, respuesta, strlen(respuesta));
	} 
	else {
		// Enviar "ERROR" al cliente si no son válidas
		char respuesta[] = "ERROR";
		printf("Usuario no encontrado, ERROR\n");
		write(sock_conn, respuesta, strlen(respuesta));
	}
}

int contarUsuariosBBDD() {
	int err;
	int totalUsuarios = 0;
	
	// Realizamos la consulta SQL para contar el número total de filas en la tabla Usuarios
	err = mysql_query(conn, "SELECT COUNT(*) FROM Usuarios;");
	
	if (err != 0) {

		// Si ocurre un error, lo mostramos
		printf("Error al contar los usuarios en la base de datos %u %s\n", mysql_errno(conn), mysql_error(conn));
		exit(1);
	} else {
		// Obtenemos el resultado de la consulta
		resultado = mysql_store_result(conn);
		if (resultado == NULL) {
			printf("Error al obtener el resultado de la consulta %u %s\n", mysql_errno(conn), mysql_error(conn));
			exit(1);
		}
		
		// Obtenemos la primera fila (el resultado del COUNT)
		row = mysql_fetch_row(resultado);
		if (row != NULL) {
			totalUsuarios = atoi(row[0]);
			printf("El número total de usuarios es: %d\n", totalUsuarios);
		}
		
		// Liberamos el resultado
		mysql_free_result(resultado);
	}
	return totalUsuarios;
}
